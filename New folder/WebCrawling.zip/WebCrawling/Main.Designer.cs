﻿namespace WebCrawling
{
    partial class WebCrawling
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(WebCrawling));
            TitleInput = new TextBox();
            URLInput = new TextBox();
            BodyInput = new RichTextBox();
            CrawlButton = new Button();
            DescriptionInput = new TextBox();
            SuspendLayout();
            // 
            // TitleInput
            // 
            TitleInput.Location = new Point(12, 50);
            TitleInput.Name = "TitleInput";
            TitleInput.ReadOnly = true;
            TitleInput.Size = new Size(760, 23);
            TitleInput.TabIndex = 0;
            TitleInput.Text = "Loading...";
            // 
            // URLInput
            // 
            URLInput.Location = new Point(12, 12);
            URLInput.Name = "URLInput";
            URLInput.PlaceholderText = "Nhap URL:";
            URLInput.Size = new Size(679, 23);
            URLInput.TabIndex = 1;
            URLInput.TextChanged += URLInput_TextChanged;
            // 
            // BodyInput
            // 
            BodyInput.ImeMode = ImeMode.Close;
            BodyInput.Location = new Point(12, 108);
            BodyInput.Name = "BodyInput";
            BodyInput.ReadOnly = true;
            BodyInput.ScrollBars = RichTextBoxScrollBars.Vertical;
            BodyInput.Size = new Size(760, 241);
            BodyInput.TabIndex = 2;
            BodyInput.Text = "Loading.....";
            // 
            // CrawlButton
            // 
            CrawlButton.Location = new Point(697, 12);
            CrawlButton.Name = "CrawlButton";
            CrawlButton.Size = new Size(75, 23);
            CrawlButton.TabIndex = 3;
            CrawlButton.Text = "Crawl";
            CrawlButton.UseVisualStyleBackColor = true;
            CrawlButton.Click += CrawlButton_Click;
            // 
            // DescriptionInput
            // 
            DescriptionInput.Location = new Point(12, 79);
            DescriptionInput.Name = "DescriptionInput";
            DescriptionInput.ReadOnly = true;
            DescriptionInput.Size = new Size(760, 23);
            DescriptionInput.TabIndex = 4;
            DescriptionInput.Text = "Loading....";
            // 
            // WebCrawling
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(784, 50);
            Controls.Add(DescriptionInput);
            Controls.Add(CrawlButton);
            Controls.Add(BodyInput);
            Controls.Add(URLInput);
            Controls.Add(TitleInput);
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "WebCrawling";
            Text = "WebCrawling";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox TitleInput;
        private TextBox URLInput;
        private RichTextBox BodyInput;
        private Button CrawlButton;
        private TextBox DescriptionInput;
    }
}
