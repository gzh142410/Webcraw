using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;

namespace WebCrawling
{
    internal class AutoChrome
    {
        private IWebDriver driver;

        public AutoChrome(bool headless = true)
        {
            var options = new ChromeOptions();
            if (headless)
            {
                options.AddArgument("--headless");

            }
            ChromeDriverService service = ChromeDriverService.CreateDefaultService();
            service.HideCommandPromptWindow = true;
            options.AddUserProfilePreference("profile.default_content_setting_values.images", 2);
            options.AddUserProfilePreference("javascript.enabled", false);
            driver = new ChromeDriver(service, options);
        }

        public void Browser(bool headless = false)
        {
            var options = new ChromeOptions();
            if (headless)
            {
                options.AddArgument("--headless");
            }
            driver = new ChromeDriver(options);
        }

        public string GetBodyContent(string url = "", bool quit = true)
        {
            string body = "Trang web không có thẻ body";
            if (url != "")
            {
                driver.Navigate().GoToUrl(url);
            }
            try
            {
                var bodyElement = driver.FindElement(By.TagName("body"));
                if (bodyElement != null)
                {
                    body = bodyElement.GetAttribute("innerHTML");
                }
                else
                {
                    body = "Không lấy được nội dung";
                }
            }
            catch
            {
                Console.WriteLine("Da phat hien loi: Dong 52 File AutoChrome.cs");
            }
            if (quit)
            {
                driver.Quit();
            }
            return body;
        }

        public string GetTitle(string url = "", bool quit = true)
        {
            try
            {
                if (url != "")
                {
                    driver.Navigate().GoToUrl(url);
                }
                string title = driver.Title;
                if (quit)
                {
                    driver.Quit();
                }
                return title;
            }
            catch
            {
                return "Chưa khởi tạo Browser";
            }
        }

        public string GetDescription(string url = "", bool quit = true)
        {
            string description = "Không tìm thấy phần mô tả!";
            if (url != "")
            {
                driver.Navigate().GoToUrl(url);
            }
            try
            {
                var metaTags = driver.FindElements(By.CssSelector("head > meta"));
                foreach (var metaTag in metaTags)
                {
                    if (metaTag.GetAttribute("property") == "og:description")
                    {
                        description = metaTag.GetAttribute("content");
                        if (description != "Không tìm thấy phần mô tả!")
                        {
                            break;
                        }
                    }
                }
            }
            catch
            {
                Console.WriteLine("Da phat hien loi: Dong 106 File AutoChrome.cs");
            }
            if (quit)
            {
                driver.Quit();
            }
            return description;
        }
    }
}
