﻿using System.Xml.Schema;
using WebCrawling;

namespace WebCrawling
{
    public partial class WebCrawling : Form
    {
        public WebCrawling()
        {
            InitializeComponent();
        }
        private string url = "";
        private void URLInput_TextChanged(object sender, EventArgs e)
        {
            url = URLInput.Text;
        }

        private void CrawlButton_Click(object sender, EventArgs e)
        {
            if (url.StartsWith("https"))
            {
                ClientSize = new Size(784, 361);
                AutoChrome chrome = new AutoChrome(false);
                string title = chrome.GetTitle(url, false);
                string description = chrome.GetDescription("", false);
                string body = chrome.GetBodyContent("", true);
                TitleInput.Text = title;
                DescriptionInput.Text = description;
                BodyInput.Text = body;
            }
            else
            {
                MessageBox.Show("URL không hợp lệ");
            }
        }
    }
}
